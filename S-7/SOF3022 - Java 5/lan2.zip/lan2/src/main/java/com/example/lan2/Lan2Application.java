package com.example.lan2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lan2Application {

    public static void main(String[] args) {
        SpringApplication.run(Lan2Application.class, args);
    }

}
