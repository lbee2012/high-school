"use strict";
function sayHi() {
  greeting = "Hello!";
  console.log(greeting);
}
sayHi();


