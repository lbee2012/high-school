let x = ;
console.log(x);








