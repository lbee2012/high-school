    /*let bmi = 21.1;
    if(bmi<18.5){
        alert("Thiếu cân");
    } 
    else if(bmi >=18.5 && bmi<25)
    {
        alert("Bình thường");
    } 
    else if(bmi>=25 && bmi<30)
    {
        alert("Thừa cân");
    }
    else
    {
        alert("Béo phì");
    }*/
    //const c = "5";
    //console.log(typeof(c));
/*let a = "Hello";
a = prompt("world");
console.log(a);*/
/*let firstNum = 5;
let secondNum = 10;
firstNum++;
secondNum--;
let total = ++firstNum + secondNum;
console.log(total);
let total2 = 500 + 100 / 5 + total--;
console.log(total2);*/
/*const a = 5;
const b = 10;
console.log(a == 3 || b == 10);*/

for (initialize variable; condition; statement) { 
    // code to be executed
}



  
    
 

