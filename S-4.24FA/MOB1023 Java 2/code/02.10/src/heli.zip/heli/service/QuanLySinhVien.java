/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heli.service;

import heli.model.SinhVien;
import java.util.ArrayList;

/**
 *
 * @author longsuwu
 */
public class QuanLySinhVien {
    ArrayList<SinhVien> svList = new ArrayList<>();
    
    public ArrayList<SinhVien> getList() {
        return svList;
    }
    
    public QuanLySinhVien() {
        svList.add(new SinhVien("01", "Hoang Quy Long", "Nam", "SD1803", "Truot mon"));
        svList.add(new SinhVien("02", "Nguyen Khanh Minh", "Nu", "SD1803", "Qua mon"));
        svList.add(new SinhVien("03", "Ta Quang The Dan", "Nam", "SD1803", "Truot mon"));
        svList.add(new SinhVien("04", "Pham Ha Anh", "Nu", "SD1803", "Qua mon"));
        svList.add(new SinhVien("05", "Duong Gia Minh", "Nam", "GD1801", "Truot mon"));
    }
    
    public String them(SinhVien sv) {
        svList.add(sv);
        return "Them thanh cong";
    }
}
